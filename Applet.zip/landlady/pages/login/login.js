//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    text: "获取验证",
    time: 60,
    timer: null,
    mobile: null,
    captcha: null,
    login_type: 1, // 1、验证码登录, 2、ID登录, 3、找回密码
  },
  showDialog() {
    this.dialog.showDialog();
  },
  getCode(event) {
    if (!this.data.mobile) {
      this.showTip('请输入手机号码!');
      return false;
    }
    if (!this.checkMobile(this.data.mobile)) {
      return this.showTip('请输入正确的手机号码!');
    }

    if (this.data.time < 60) {
      return false;
    }
    this.countDown();
    let timer = setInterval(this.countDown, 1000);
    this.setData({
      timer: timer
    });
  },
  onUnload() {
    clearInterval(this.data.timer);
  },
  getMobile(e) {
    if (e.detail.value.length < 1) {
      this.setData({
        mobile: null,
      });
    } else {
      this.setData({
        mobile: e.detail.value
      });
    }
  },
  getCaptcha(e) {
    if (e.detail.value.length < 1) {
      this.setData({
        captcha: null,
      });
    } else {
      this.setData({
        captcha: e.detail.value
      });
    }
  },
  countDown() {
    console.log(this.data.time);
    if (this.data.time > 0) {
      this.data.time--;
      this.setData({
        text: this.data.time + '秒',
      });
    } else {
      // 清除定时器
      clearInterval(this.data.timer);
      this.setData({
        text: '获取验证',
      });
    }
  },
  submit(event) {
    // 页面跳装
    wx.switchTab({
      url: '/pages/index/index'
    });
  },
  showTip(text, icon = 'none', duration = 1000) {
    wx.showToast({
      title: text,
      icon: icon,
      duration: duration
    });
  },
  checkMobile(mobile) {
    let reg = /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/
    return reg.test(mobile)
  },
  changeType(e) {
    this.setData({
      login_type: e.currentTarget.dataset.type
    });
  }
})